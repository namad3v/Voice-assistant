package com.example.voiceassistant

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Start background voice service
        val intent = Intent(this, VoiceService::class.java)
        startForegroundService(intent)

        // Close the activity (assistant runs in background only)
        finish()
    }
}